// ===== Language Toggle =====
const langToggle = document.getElementById('langToggle');
const langLabel = document.getElementById('langLabel');
const body = document.body;

// Load saved language preference
let currentLang = localStorage.getItem('portfolioLang') || 'en';
applyLanguage(currentLang);

langToggle.addEventListener('click', () => {
    currentLang = currentLang === 'en' ? 'kr' : 'en';
    applyLanguage(currentLang);
    localStorage.setItem('portfolioLang', currentLang);
});

function applyLanguage(lang) {
    const elements = document.querySelectorAll('[data-en], [data-kr]');
    elements.forEach(el => {
        const translation = el.getAttribute(`data-${lang}`);
        if (translation !== null) {
            el.textContent = translation;
        }
    });
    
    // Update HTML lang attribute
    document.documentElement.lang = lang === 'kr' ? 'ko' : 'en';
    
    // Update body class for font family
    if (lang === 'kr') {
        body.classList.add('lang-kr');
    } else {
        body.classList.remove('lang-kr');
    }
    
    // Update toggle button to show the OTHER language (what it will switch to)
    langLabel.textContent = lang === 'en' ? 'KR' : 'EN';
    
    // Update page title
    document.title = lang === 'kr' 
        ? '김지혜 | 디지털 마케팅 포트폴리오' 
        : 'Jihye Kim | Digital Marketing Portfolio';
}

// ===== Mobile Menu =====
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

// Close menu when clicking a nav link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
    });
});

// ===== Navbar Scroll Effect =====
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// ===== Intersection Observer for Fade-in Animations =====
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, observerOptions);

// Apply fade-in to cards & content blocks
document.querySelectorAll(
    '.highlight-card, .skill-category, .timeline-item, .campaign-card, .cert-card, .extras-card, .stat-card'
).forEach(el => {
    el.classList.add('fade-in');
    fadeObserver.observe(el);
});

// ===== Smooth Scroll Offset for Anchor Links =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href === '#') return;
        
        const target = document.querySelector(href);
        if (target) {
            e.preventDefault();
            const offset = 80;
            const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    });
});
