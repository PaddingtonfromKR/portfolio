# Jihye Kim — Digital Marketing Portfolio (Bilingual EN/KR)

A modern, responsive, single-page bilingual portfolio website for digital marketing professional Jihye Kim. Designed to be recruiter-friendly and deployable for free.

## 🎯 Project Goals

- Showcase Jihye Kim's digital marketing expertise to recruiters globally and in Korea
- Provide seamless language toggle between English and Korean
- Work as a shareable link for job applications (LinkedIn, email signature, resume)
- Be easy to edit and deploy with no coding knowledge required

## ✅ Completed Features

- ✅ **Bilingual content** — Full EN/KR translations across every section
- ✅ **Language toggle button** (top-right, globe icon) — Switches entire site instantly, remembers preference in localStorage
- ✅ **Responsive design** — Looks great on mobile, tablet, and desktop
- ✅ **Modern UI** — Clean typography (Inter + Noto Sans KR), purple/indigo accent, soft shadows
- ✅ **Smooth scrolling navigation** with scroll-aware navbar
- ✅ **Fade-in animations** on scroll (Intersection Observer)
- ✅ **Mobile hamburger menu**
- ✅ **All sections included**:
  1. Hero with headline, tagline, CTA, stats
  2. About / Professional Summary (with 3 highlight cards)
  3. Skills & Tools (4 categories + KPI badges)
  4. Work Experience (timeline, 3 placeholder entries)
  5. Featured Campaigns / Case Studies (3 placeholder cards with Challenge-Strategy-Results)
  6. Certifications (8 cards: Google, Meta, The Trade Desk, Coursera, etc.)
  7. Languages & Volunteer Experience
  8. Contact section with email & LinkedIn CTA

## 📁 File Structure

```
index.html          — Main single-page site
css/style.css       — All styling (responsive, modern design system)
js/main.js          — Language toggle, mobile menu, scroll effects
README.md           — This file
```

## 🔗 Functional Entry URIs

| Path | Description |
|------|-------------|
| `/` or `/index.html` | Main portfolio page (single-page site) |
| `#home` | Hero section |
| `#about` | Professional Summary |
| `#skills` | Core Competencies & Tools |
| `#experience` | Work Experience timeline |
| `#campaigns` | Featured Campaigns / Case Studies |
| `#certifications` | Certifications grid |
| `#contact` | Contact section |

**Language toggle**: Click the "KR" / "EN" button in the top-right. Preference is saved in browser localStorage.

## ✏️ What YOU Need to Customize

Before publishing, update these placeholders in `index.html`:

1. **Email** — Replace `your.email@example.com` (appears 3 times) with your real email
2. **Work Experience** (section `#experience`) — Replace 3 placeholder entries:
   - Company names, roles, dates
   - Bullet points with quantifiable achievements
3. **Featured Campaigns** (section `#campaigns`) — Replace 3 case studies:
   - Campaign title, client, industry, year
   - Challenge / Strategy / Results text
   - Real metrics (ROAS, CPA, CTR, etc.)
   - Tools used
4. **Hero stats** (optional) — Currently shows "10+ Certifications / 2 Languages / ∞ Data-driven" — tweak if desired
5. **Profile photo** (optional) — Not included by default; you can add `<img src="images/profile.jpg">` to the hero section

## 🚀 How to Deploy (Free Options)

### Option 1: Netlify (Easiest, Recommended) — FREE
1. Go to https://app.netlify.com/drop
2. Drag-and-drop the entire project folder
3. Instantly get a live URL like `jihye-kim.netlify.app`
4. Optional: Add custom domain (~$12/year from Namecheap/Gabia)

### Option 2: Vercel — FREE
1. Sign up at https://vercel.com
2. Import your project (GitHub or drag-drop)
3. Deploy → Get `yourname.vercel.app`

### Option 3: GitHub Pages — FREE
1. Create a GitHub account and new repo named `yourname.github.io`
2. Upload the files
3. Site is live at `https://yourname.github.io`

### Option 4: Custom Domain (Professional touch)
1. Buy domain from Namecheap / GoDaddy / Gabia (~$10-15/year)
2. Connect it to Netlify/Vercel (free hosting)
3. **Total cost: ~$12/year**

## 🛠️ Tech Stack

- **HTML5** (semantic tags: `<header>`, `<section>`, `<article>`, `<nav>`, `<footer>`)
- **CSS3** (CSS Variables, Grid, Flexbox, responsive breakpoints)
- **Vanilla JavaScript** (no frameworks, super fast)
- **Google Fonts**: Inter + Noto Sans KR
- **Font Awesome 6** for icons
- **No build step required** — pure static files

## 📊 Data Models

The portfolio uses static content embedded in HTML with `data-en` and `data-kr` attributes for bilingual content. No database or backend is required.

```html
<element data-en="English text" data-kr="한국어 텍스트">English text</element>
```

JavaScript reads these attributes and swaps text on language toggle.

## 🔮 Features Not Yet Implemented (Optional Future Enhancements)

- [ ] Profile photo / avatar in hero section
- [ ] PDF resume download button
- [ ] Case study detail pages (modal or separate pages)
- [ ] Contact form (would need a service like Formspree or Netlify Forms)
- [ ] Dark mode toggle
- [ ] Blog / Articles section
- [ ] Testimonials / Recommendations section
- [ ] Analytics integration (Google Analytics)

## 📝 Recommended Next Steps

1. **Fill in real content** — Replace all placeholder work experience and campaign details
2. **Add a profile photo** — Upload to `images/profile.jpg` and reference it in the hero
3. **Test the language toggle** — Click the KR/EN button to verify all translations
4. **Deploy to Netlify** — Get a shareable URL within 2 minutes
5. **Add to LinkedIn** — Paste the URL in your LinkedIn "Contact Info" or "Featured" section
6. **Optional: Buy custom domain** — e.g., `jihyekim.com` for a premium feel
7. **Optional: Add Google Analytics** — Track recruiter visits

## 💡 Tips

- **Preview locally**: Just double-click `index.html` to open it in your browser
- **Edit text quickly**: Search for `[Replace` or `[Edit` in `index.html` to find all placeholders
- **Keep it updated**: Each time you add a new certification or campaign, come back and update

---

© 2025 Jihye Kim — Built as a bilingual digital marketing portfolio.
